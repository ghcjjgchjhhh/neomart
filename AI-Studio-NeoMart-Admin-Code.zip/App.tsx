import React, { useState, useEffect, useRef } from 'react';
import { Header } from './components/Header';
import { CategoryNav } from './components/CategoryNav';
import { Sidebar } from './components/Sidebar';
import { HeroSlider } from './components/HeroSlider';
import { CustomerBanner } from './components/CustomerBanner';
import { FlashSales } from './components/FlashSales';
import { BrandsStrip } from './components/BrandsStrip';
import { ProductCard } from './components/ProductCard';
import { ProductDetail } from './components/ProductDetail';
import { CartSidebar } from './components/CartSidebar';
import { CheckoutModal } from './components/CheckoutModal';
import { PaymentSuccessModal } from './components/PaymentSuccessModal';
import { LoginModal } from './components/LoginModal';
import { HelpCenterModal } from './components/HelpCenterModal';
import { AdminOrdersModal } from './components/AdminOrdersModal';
import { ConfirmOrdersModal } from './components/ConfirmOrdersModal';
import { AdminOrderAlert } from './components/AdminOrderAlert';
import { AdminStockModal } from './components/AdminStockModal';
import { OrderHistoryModal } from './components/OrderHistoryModal';
import { AdminSalesReportModal } from './components/AdminSalesReportModal';
import { AdminCustomersModal, type AccountState } from './components/AdminCustomersModal';
import { OrderTrackingModal } from './components/TrackingModal';
import { Footer } from './components/Footer';
import { Toast } from './components/Toast';
import { SplashScreen } from './components/SplashScreen';

const ADMIN_EMAIL = 'ifeanyianoma2@gmail.com';
const SUPPORT_PHONE = '08135642842';

import { allProducts as initialProducts, flashProductIds } from './data/products';
import { initialReviews, sampleOrders } from './data/ordersAndReviews';
import { confirmOrderPayment, getOrders, saveOrder, saveCustomerProfile, subscribeToOrders, updateOrderStatus, updateOrderDelivery, saveStockLevel, subscribeToStock, subscribeToCustomerAccountState, updateCustomerAccountState, getCustomerAccountState } from './config/ordersService';
import { auth, getGoogleRedirectUser } from './config/firebase';
import {
  Product,
  CartItem,
  Review,
  Order,
  CategoryId,
  HelpSectionType,
  PaymentMethodType,
  DeliveryDetails
} from './types';

import {
  Smartphone,
  Laptop,
  Tv,
  Shirt,
  Flame,
  Gamepad2,
  HeartPulse,
  Home,
  Baby,
  Clock,
  Headphones,
  Footprints,
  SlidersHorizontal,
  ArrowUpDown,
  Package,
  Warehouse,
  BarChart3,
  Users,
  MessageCircle,
  Send,
  TrendingUp,
  AlertTriangle,
  LayoutDashboard
} from 'lucide-react';

export default function App() {
  const trackingPathMatch = window.location.pathname.match(/^\/track\/([^/]+)$/i);
  const trackingPathOrderId = trackingPathMatch ? decodeURIComponent(trackingPathMatch[1]) : null;
  const isAdminPath = /^\/admin\/?$/i.test(window.location.pathname);

  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem('neomart_products');
      return saved ? JSON.parse(saved) : initialProducts;
    } catch {
      return initialProducts;
    }
  });
  const allProducts = products;

  useEffect(() => {
    localStorage.setItem('neomart_products', JSON.stringify(products));
  }, [products]);

  // Theme state
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    const saved = localStorage.getItem('neomart_theme');
    if (saved === 'dark' || saved === 'light') return saved;
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches
      ? 'dark'
      : 'light';
  });

  // Authentication state
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(() => {
    return localStorage.getItem('neomart_logged_in') === 'true';
  });
  const [currentUserEmail, setCurrentUserEmail] = useState(() =>
    localStorage.getItem('neomart_user_email') || ''
  );
  const [sessionStartedAt, setSessionStartedAt] = useState(() =>
    Number(localStorage.getItem('neomart_session_started_at')) || Date.now()
  );
  const [accountName, setAccountName] = useState(() =>
    localStorage.getItem('neomart_account_name') || ''
  );
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isCustomerAccessBlocked, setIsCustomerAccessBlocked] = useState(false);

  // Cart state
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('neomart_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [isCartOpen, setIsCartOpen] = useState(false);

  // Reviews state
  const [reviews, setReviews] = useState<Review[]>(() => {
    try {
      const saved = localStorage.getItem('neomart_reviews');
      return saved ? JSON.parse(saved) : initialReviews;
    } catch {
      return initialReviews;
    }
  });

  // Orders state
  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem('neomart_orders');
      const storedOrders: Order[] = saved
        ? (JSON.parse(saved) as Order[]).filter(
            (order) => !sampleOrders.some((sampleOrder) => sampleOrder.id === order.id)
          )
        : [];
      return storedOrders.map((order) =>
        order.phone === SUPPORT_PHONE ? { ...order, phone: '' } : order
      ).map((order) =>
        !order.paymentConfirmed &&
        order.paymentMethod !== 'Payment on Delivery' &&
        (order.status === 'Out for Delivery' || order.status === 'Order Confirmed')
          ? { ...order, status: 'Processing', paymentConfirmed: false }
          : order
      );
    } catch {
      return [];
    }
  });
  const [isOrderTrackingOpen, setIsOrderTrackingOpen] = useState(Boolean(trackingPathOrderId));
  const [trackingOrderId, setTrackingOrderId] = useState<string | null>(trackingPathOrderId);
  const [lastPlacedOrderId, setLastPlacedOrderId] = useState<string | null>(null);
  const lastPlacedOrderIdRef = useRef<string | null>(null);
  const remoteStatusesRef = useRef<Record<string, string>>({});
  const hasReceivedOrdersRef = useRef(false);
  const knownOrderIdsRef = useRef<Set<string>>(new Set());

  // UI Views & Modals state
  const [selectedCategory, setSelectedCategory] = useState<CategoryId>('all');
  const [selectedProductId, setSelectedProductId] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [sortOption, setSortOption] = useState<'featured' | 'price-low' | 'price-high' | 'rating'>('featured');

  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isPaymentSuccessOpen, setIsPaymentSuccessOpen] = useState(false);
  const [lastPaymentMethod, setLastPaymentMethod] = useState<PaymentMethodType>('delivery');

  const [isHelpOpen, setIsHelpOpen] = useState(false);
  const [currentView, setCurrentView] = useState<'store' | 'admin'>(isAdminPath ? 'admin' : 'store');
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isConfirmOrdersOpen, setIsConfirmOrdersOpen] = useState(false);
  const [isStockOpen, setIsStockOpen] = useState(false);
      const [isOrderHistoryOpen, setIsOrderHistoryOpen] = useState(false);
      const [isSalesReportOpen, setIsSalesReportOpen] = useState(false);
      const [isCustomerManagementOpen, setIsCustomerManagementOpen] = useState(false);
      const [customerOrderIds, setCustomerOrderIds] = useState<string[]>(() => {
        try {
          const saved = localStorage.getItem('neomart_customer_order_ids');
          return saved ? JSON.parse(saved) : [];
        } catch {
          return [];
        }
      });
    const [stockLevels, setStockLevels] = useState<Record<number, number>>(() => {
      try {
        const saved = localStorage.getItem('neomart_stock_levels');
        return saved ? JSON.parse(saved) : {};
      } catch {
        return {};
      }
    });
  const [activeHelpSection, setActiveHelpSection] = useState<HelpSectionType>('place-order');

  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [adminOrderAlert, setAdminOrderAlert] = useState<Order | null>(null);
  const [adminChatInput, setAdminChatInput] = useState('');
  const [adminChatMessages, setAdminChatMessages] = useState([
    { from: 'support', text: 'Good morning. I am watching today\'s orders with you.' },
    { from: 'support', text: 'Ask me to surface pending payments or stock risks.' },
  ]);
  const [showSplash, setShowSplash] = useState(true);

  useEffect(() => {
    void getGoogleRedirectUser().then((user) => {
      if (!user) return;
      const email = user.email || user.uid;
      const name = user.displayName || email.split('@')[0];
      return getCustomerAccountState(email).then((state) => {
        if (state.revokedAt || state.disabled || state.deletedAt) {
          setIsCustomerAccessBlocked(true);
          setIsLoginOpen(true);
          showToast('This account is blocked by NeoMart support.');
          return;
        }
        setIsCustomerAccessBlocked(false);
      setIsLoggedIn(true);
      setCurrentUserEmail(email);
      setAccountName(name);
      const startedAt = Date.now();
      setSessionStartedAt(startedAt);
      localStorage.setItem('neomart_logged_in', 'true');
      localStorage.setItem('neomart_user_email', email);
      localStorage.setItem('neomart_account_name', name);
      localStorage.setItem('neomart_session_started_at', String(startedAt));
      if (email.toLowerCase() === ADMIN_EMAIL) {
        setCurrentView('admin');
        window.history.replaceState({}, '', '/admin');
      }
      showToast(`Signed in with Google as ${email}`);
      });
    }).catch(() => {
      showToast('Google sign-in failed. Check Firebase Google sign-in settings.');
    });
  }, []);

  useEffect(() => {
    const email = currentUserEmail.trim().toLowerCase();
    if (!email || email === ADMIN_EMAIL) return;
    let unsubscribe: (() => void) | null = null;
    subscribeToCustomerAccountState(email, (state) => {
      if (!state.revokedAt && !state.disabled && !state.deletedAt) {
        setIsCustomerAccessBlocked(false);
        return;
      }
      setIsCustomerAccessBlocked(true);
      setIsLoggedIn(false);
      setCurrentUserEmail('');
      setAccountName('');
      localStorage.removeItem('neomart_logged_in');
      localStorage.removeItem('neomart_user_email');
      localStorage.removeItem('neomart_account_name');
      showToast('Your NeoMart session was signed out by support.');
    }).then((cleanup) => {
      unsubscribe = cleanup;
    }).catch(() => {});
    return () => unsubscribe?.();
  }, [currentUserEmail, sessionStartedAt]);

  // Sync theme
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('neomart_theme', theme);
  }, [theme]);

  // Sync cart
  useEffect(() => {
    localStorage.setItem('neomart_cart', JSON.stringify(cart));
  }, [cart]);

  // Sync reviews
  useEffect(() => {
    localStorage.setItem('neomart_reviews', JSON.stringify(reviews));
  }, [reviews]);

  // Sync orders
  useEffect(() => {
    localStorage.setItem('neomart_orders', JSON.stringify(orders));
  }, [orders]);

  // Keep customer and admin order lists synchronized across devices when Firebase is configured.
  useEffect(() => {
    let isActive = true;
    let unsubscribe: (() => void) | null = null;

    subscribeToOrders((remoteOrders) => {
      const realOrders = remoteOrders.filter(
        (order) =>
          order.orderSource === 'customer' &&
          !sampleOrders.some((sampleOrder) => sampleOrder.id === order.id)
      );
      const newOrders = realOrders.filter((order) => !knownOrderIdsRef.current.has(order.id));
      const isAdmin = localStorage.getItem('neomart_user_email')?.toLowerCase() === ADMIN_EMAIL;
      if (hasReceivedOrdersRef.current && isAdmin) {
        const newOrder = newOrders.find((order) => order.id !== lastPlacedOrderIdRef.current);
        if (newOrder) {
          setAdminOrderAlert(newOrder);
          if ('Notification' in window && Notification.permission === 'granted') {
            new Notification('New NeoMart order', {
              body: `Order #${newOrder.id} for ₦${newOrder.total.toLocaleString()} is waiting for review.`,
              icon: '/favicon.ico',
            });
          }
        }
      }
      knownOrderIdsRef.current = new Set(realOrders.map((order) => order.id));
      if (hasReceivedOrdersRef.current && lastPlacedOrderIdRef.current) {
        const order = realOrders.find((item) => item.id === lastPlacedOrderIdRef.current);
        const previousStatus = remoteStatusesRef.current[lastPlacedOrderIdRef.current];
        if (order && previousStatus && order.status !== previousStatus) {
          showToast(
            order.paymentConfirmed === true
              ? 'Your order has been confirmed by NeoMart.'
              : `Your order is now ${order.status}.`
          );
        }
      }
      remoteStatusesRef.current = Object.fromEntries(
        realOrders.map((order) => [order.id, order.status])
      );
      hasReceivedOrdersRef.current = true;
      if (isActive) setOrders(realOrders);
    }).then((cleanup) => {
      if (isActive) unsubscribe = cleanup;
      else cleanup?.();
    }).catch((error) => {
      console.error('Could not connect to shared orders:', error);
    });

    return () => {
      isActive = false;
      unsubscribe?.();
    };
  }, []);

  useEffect(() => {
    let unsubscribe: (() => void) | null = null;
    subscribeToStock((remoteStock) => {
      setStockLevels(remoteStock);
      localStorage.setItem('neomart_stock_levels', JSON.stringify(remoteStock));
      window.dispatchEvent(new Event('neomart-stock-updated'));
    }).then((cleanup) => {
      unsubscribe = cleanup;
    }).catch(() => {});
    return () => unsubscribe?.();
  }, []);

  useEffect(() => {
    if (!isLoggedIn || currentUserEmail.toLowerCase() !== ADMIN_EMAIL) return;

    const refreshOrders = () => {
      void getOrders().then((remoteOrders) => {
        const realOrders = remoteOrders.filter(
          (order) =>
            order.orderSource === 'customer' &&
            !sampleOrders.some((sampleOrder) => sampleOrder.id === order.id)
        );
        setOrders(realOrders);
      }).catch(() => {});
    };

    const refreshTimer = window.setInterval(refreshOrders, 3000);
    return () => window.clearInterval(refreshTimer);
  }, [currentUserEmail, isLoggedIn]);

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'light' ? 'dark' : 'light'));
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3000);
  };

  const enableAdminNotifications = async () => {
    if (!('Notification' in window)) {
      showToast('This browser does not support phone alerts.');
      return;
    }
    const permission = await Notification.requestPermission();
    showToast(
      permission === 'granted'
        ? 'Phone alerts enabled for new orders.'
        : 'Phone alerts were not enabled.'
    );
  };

  // Cart Operations
  const getStockLevel = (productId: number) => {
    return stockLevels[productId] ?? 10;
  };

  const handleUpdateStock = (productId: number, quantity: number) => {
    setStockLevels((previous) => {
      const updated = { ...previous, [productId]: quantity };
      localStorage.setItem('neomart_stock_levels', JSON.stringify(updated));
      window.dispatchEvent(new Event('neomart-stock-updated'));
      return updated;
    });
    void saveStockLevel(productId, quantity).catch(() => {
      showToast('Could not sync stock. Check Firebase connection.');
    });
  };

  const handleAddToCart = (product: Product) => {
    let added = true;
    setCart((prev) => {
      const existing = prev.find((item) => item.id === product.id);
      if (getStockLevel(product.id) <= (existing?.qty || 0)) {
        showToast(`${product.name.slice(0, 28)}... is unavailable`);
        added = false;
        return prev;
      }
      if (existing) {
        return prev.map((item) =>
          item.id === product.id ? { ...item, qty: item.qty + 1 } : item
        );
      }
      return [...prev, { ...product, qty: 1 }];
    });
    if (added) showToast(`${product.name.slice(0, 28)}... added to cart 🛒`);
    return added;
  };

  const handleChangeQty = (productId: number, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) => {
          if (item.id === productId) {
            const newQty = item.qty + delta;
            return newQty > 0 ? { ...item, qty: newQty } : null;
          }
          return item;
        })
        .filter((item): item is CartItem => item !== null)
    );
  };

  const handleRemoveCartItem = (productId: number) => {
    setCart((prev) => prev.filter((item) => item.id !== productId));
    showToast('Item removed from cart');
  };

  // Reviews operations
  const handleAddReview = (newReview: Omit<Review, 'id' | 'date' | 'helpful'>) => {
    const reviewObj: Review = {
      ...newReview,
      id: Date.now(),
      date: new Date().toISOString().split('T')[0],
      helpful: 0
    };
    setReviews((prev) => [reviewObj, ...prev]);
    showToast('Review submitted successfully! Thank you ⭐');
  };

  const handleVoteHelpful = (reviewId: number) => {
    setReviews((prev) =>
      prev.map((r) => (r.id === reviewId ? { ...r, helpful: r.helpful + 1 } : r))
    );
  };

  // Category & Product Navigation
  const handleSelectCategory = (cat: CategoryId | string) => {
    setSelectedCategory(cat as CategoryId);
    setSelectedProductId(null);
    if (cat === 'all') {
      setIsSearching(false);
      setSearchQuery('');
    } else {
      setIsSearching(true);
      setSearchQuery(cat);
    }
  };

  const handleSelectProduct = (productId: number) => {
    setSelectedProductId(productId);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBackToCatalog = () => {
    setSelectedProductId(null);
  };

  const handleSearchSubmit = (query: string) => {
    setSearchQuery(query);
    setIsSearching(true);
    setSelectedProductId(null);
  };

  const handleOpenHelpSection = (section: HelpSectionType) => {
    setActiveHelpSection(section);
    setIsHelpOpen(true);
  };

  const openAdminPortal = () => {
    setCurrentView('admin');
    setIsAdminOpen(true);
    window.history.pushState({}, '', '/admin');
  };

  const openStorefront = () => {
    setCurrentView('store');
    setIsAdminOpen(false);
    window.history.pushState({}, '', '/');
  };

  const handleConfirmOrderPayment = async (orderId: string) => {
    const previousOrders = orders;
    setOrders((prev) =>
      prev.map((order) =>
        order.id === orderId
          ? { ...order, status: 'Order Confirmed', paymentConfirmed: true }
          : order
      )
    );
    try {
      const saved = await confirmOrderPayment(orderId);
      if (!saved) throw new Error('Firebase authentication is unavailable');
      showToast('Order confirmed successfully');
    } catch (error) {
      setOrders(previousOrders);
      const message = error instanceof Error ? error.message : 'Firebase could not save the confirmation';
      showToast(`Confirmation failed: ${message}`);
    }
  };

  // Checkout flow
  const handleStartCheckout = () => {
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };

  const handleOpenLiveTracking = (orderId?: string) => {
    const nextOrderId = orderId || null;
    setTrackingOrderId(nextOrderId);
    setIsOrderTrackingOpen(true);
    if (nextOrderId) {
      window.history.pushState({}, '', `/track/${encodeURIComponent(nextOrderId)}`);
    }
  };

  const customerOrdersForAccount = orders.filter(
    (order) =>
      order.orderSource === 'customer' &&
      (order.email === currentUserEmail || customerOrderIds.includes(order.id))
  );

  const handleCompleteOrder = (
    method: PaymentMethodType,
    _deliveryDetails?: DeliveryDetails,
    discountAmount = 0
  ) => {
    setLastPaymentMethod(method);

    const unavailableItem = cart.find((item) => item.qty > getStockLevel(item.id));
    if (unavailableItem) {
      showToast(`${unavailableItem.name.slice(0, 28)}... is unavailable or has insufficient stock`);
      return;
    }

    // Create real Order item
    const newOrderId = 'NM-' + Math.floor(10000 + Math.random() * 90000);
    const orderItems = cart.map((c) => ({
      name: c.name,
      qty: c.qty,
      price: c.price,
      image: c.img || ''
    }));
    const calculatedTotal = cart.reduce((s, i) => s + i.price * i.qty, 0);

    const fullAddress = _deliveryDetails?.address
      ? `${_deliveryDetails.address}, ${_deliveryDetails.city}, ${_deliveryDetails.state}`
      : 'Plot 8, Sangotedo, Lekki-Epe Expressway, Lagos';

    const newOrder: Order = {
      id: newOrderId,
      orderSource: 'customer',
      phone: _deliveryDetails?.phone?.trim() || '',
      email: currentUserEmail.includes('@') ? currentUserEmail : '',
      customerName: accountName || undefined,
      date: new Date().toISOString().split('T')[0],
      eta: new Date(Date.now() + 2 * 86400000).toISOString().split('T')[0],
      status: method === 'delivery' ? 'Order Placed' : 'Processing',
      paymentConfirmed: false,
      paymentMethod:
        method === 'delivery'
          ? 'Payment on Delivery'
          : method === 'card'
          ? 'Card Payment'
          : 'Bank Transfer (GTBank)',
      address: fullAddress,
      total: Math.max(0, (calculatedTotal > 0 ? calculatedTotal : 150000) - discountAmount),
      items:
        orderItems.length > 0
          ? orderItems
          : [
              {
                name: 'NeoMart Express Priority Package',
                qty: 1,
                price: 150000,
                image: 'https://ng.jumia.is/unsafe/fit-in/500x500/filters:fill(white)/product/57/5777743/1.jpg?5669'
              }
            ]
    };

    lastPlacedOrderIdRef.current = newOrderId;
    setCustomerOrderIds((previous) => {
      const updatedIds = [newOrderId, ...previous.filter((id) => id !== newOrderId)];
      localStorage.setItem('neomart_customer_order_ids', JSON.stringify(updatedIds));
      return updatedIds;
    });
    const updated = [newOrder, ...orders];
    setOrders(updated);
    void saveOrder(newOrder).catch(() => {
      showToast('Order saved locally. Firebase sync is unavailable.');
    });
    void saveCustomerProfile({
      email: newOrder.email,
      phone: newOrder.phone,
      savedAddresses: [newOrder.address],
      lastOrderId: newOrder.id,
    }).catch(() => {});
    void fetch('/api/notify-order', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ orderId: newOrder.id, total: newOrder.total }),
    }).catch(() => {});

    try {
      const saved = localStorage.getItem('neomart_stock_levels');
      const levels = { ...stockLevels };
      orderItems.forEach((item) => {
        const product = allProducts.find((candidate) => candidate.name === item.name);
        if (product) levels[product.id] = Math.max(0, getStockLevel(product.id) - item.qty);
        if (product) {
          levels[product.id] = Math.max(0, getStockLevel(product.id) - item.qty);
          void saveStockLevel(product.id, levels[product.id]).catch(() => {});
        }
      });
      setStockLevels(levels);
      localStorage.setItem('neomart_stock_levels', JSON.stringify(levels));
    } catch {
      // Keep checkout successful if stock persistence is unavailable.
    }
    setLastPlacedOrderId(newOrderId);

    setCart([]);
    setIsCheckoutOpen(false);
    setIsPaymentSuccessOpen(true);
    showToast(method === 'delivery' ? 'Order Placed Successfully! 📦' : 'Payment Received! 💳');
  };

  // Data Filtering
  const getFilteredProducts = () => {
    let list = [...allProducts];

    if (isSearching && searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.tags.some((t) => t.toLowerCase().includes(q)) ||
          p.category.toLowerCase().includes(q)
      );
    } else if (selectedCategory !== 'all') {
      list = list.filter(
        (p) => p.category === selectedCategory || p.tags.includes(selectedCategory)
      );
    }

    if (sortOption === 'price-low') {
      list.sort((a, b) => a.price - b.price);
    } else if (sortOption === 'price-high') {
      list.sort((a, b) => b.price - a.price);
    } else if (sortOption === 'rating') {
      list.sort((a, b) => b.rating - a.rating);
    }

    return list;
  };

  const filteredList = getFilteredProducts();
  const selectedProduct = allProducts.find((p) => p.id === selectedProductId);
  const flashProducts = flashProductIds
    .map((id) => allProducts.find((p) => p.id === id))
    .filter((p): p is Product => Boolean(p));

  const totalCartCount = cart.reduce((sum, item) => sum + item.qty, 0);
  const allCustomerOrders = orders.filter((order) => order.orderSource === 'customer');
  const customerOrders = allCustomerOrders;
  const confirmedCustomerOrders = allCustomerOrders.filter((order) => order.paymentConfirmed === true);
  const pendingCustomerOrders = allCustomerOrders.filter((order) => order.paymentConfirmed !== true);
  const processingCustomerOrders = allCustomerOrders.filter((order) => order.status === 'Processing');
  const deliveredCustomerOrders = allCustomerOrders.filter((order) => order.status === 'Delivered');
  const confirmedRevenue = confirmedCustomerOrders.reduce((total, order) => total + order.total, 0);
  const pieTotal = Math.max(allCustomerOrders.length, 1);
  const pieConfirmed = Math.round((confirmedCustomerOrders.length / pieTotal) * 100);
  const pieProcessing = Math.round((processingCustomerOrders.length / pieTotal) * 100);
  const pieDelivered = Math.max(0, 100 - pieConfirmed - pieProcessing);

  const categoryCards = [
    { id: 'phone', label: 'Phones', icon: <Smartphone className="w-6 h-6 text-[#f68b1e]" /> },
    { id: 'laptop', label: 'Laptops', icon: <Laptop className="w-6 h-6 text-[#f68b1e]" /> },
    { id: 'tv', label: 'TVs', icon: <Tv className="w-6 h-6 text-[#f68b1e]" /> },
    { id: 'appliance', label: 'Appliances', icon: <Flame className="w-6 h-6 text-[#f68b1e]" /> },
    { id: 'fashion', label: 'Fashion', icon: <Shirt className="w-6 h-6 text-[#f68b1e]" /> },
    { id: 'gaming', label: 'Gaming', icon: <Gamepad2 className="w-6 h-6 text-[#f68b1e]" /> },
    { id: 'watch', label: 'Watches', icon: <Clock className="w-6 h-6 text-[#f68b1e]" /> },
    { id: 'headphone', label: 'Audio', icon: <Headphones className="w-6 h-6 text-[#f68b1e]" /> },
    { id: 'shoe', label: 'Shoes', icon: <Footprints className="w-6 h-6 text-[#f68b1e]" /> },
    { id: 'home', label: 'Home', icon: <Home className="w-6 h-6 text-[#f68b1e]" /> },
    { id: 'health', label: 'Health', icon: <HeartPulse className="w-6 h-6 text-[#f68b1e]" /> },
    { id: 'baby', label: 'Baby', icon: <Baby className="w-6 h-6 text-[#f68b1e]" /> }
  ];

  if (currentView === 'admin') {
    return (
      <div className="admin-dashboard min-h-screen bg-[#0d1012] text-gray-100 transition-colors">
        <div className="mx-auto grid min-h-screen max-w-[1500px] lg:grid-cols-[220px_1fr]">
          <aside className="hidden border-r border-gray-200 bg-[#171b1d] p-5 text-white lg:flex lg:flex-col dark:border-gray-800">
            <div className="flex items-center gap-2 border-b border-white/10 pb-6"><div className="grid h-9 w-9 place-items-center rounded-xl bg-[#f68b1e] font-black">N</div><div><div className="font-black">NeoMart</div><div className="text-[10px] uppercase tracking-[0.18em] text-gray-400">Control room</div></div></div>
            <nav className="mt-8 space-y-2 text-sm font-bold"><div className="flex items-center gap-3 rounded-xl bg-[#f68b1e] px-3 py-3"><LayoutDashboard className="h-4 w-4" />Overview</div><button onClick={() => setIsAdminOpen(true)} className="flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left text-gray-400 transition hover:bg-white/10 hover:text-white"><Package className="h-4 w-4" />Orders <span className="ml-auto rounded-full bg-red-500 px-2 py-0.5 text-[10px] text-white">{pendingCustomerOrders.length}</span></button><button onClick={() => setIsStockOpen(true)} className="flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left text-gray-400 transition hover:bg-white/10 hover:text-white"><Warehouse className="h-4 w-4" />Inventory</button><button onClick={() => setIsCustomerManagementOpen(true)} className="flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left text-gray-400 transition hover:bg-white/10 hover:text-white"><Users className="h-4 w-4" />Customers</button></nav>
            <div className="mt-auto rounded-2xl border border-white/10 bg-white/5 p-4"><div className="mb-2 flex items-center gap-2 text-xs font-bold text-emerald-300"><span className="h-2 w-2 rounded-full bg-emerald-400" />All systems operational</div><p className="text-[11px] leading-5 text-gray-400">Orders, payments and inventory are syncing.</p></div>
          </aside>
          <main className="min-w-0 px-4 py-5 sm:px-7 lg:px-9 lg:py-8">
            <div className="mb-7 flex flex-wrap items-center justify-between gap-4"><div><p className="text-xs font-black uppercase tracking-[0.22em] text-[#f68b1e]">Friday, September 04</p><h1 className="mt-1 text-3xl font-black tracking-tight text-gray-950 dark:text-white">Good morning, Franklin</h1><p className="mt-1 text-sm text-gray-500">Here is what is happening across your store.</p></div><div className="flex items-center gap-2"><button type="button" onClick={openStorefront} className="rounded-xl border border-gray-300 bg-white px-4 py-2.5 text-sm font-bold text-gray-700 transition hover:border-[#f68b1e] hover:text-[#f68b1e] dark:border-gray-700 dark:bg-[#18181b] dark:text-gray-200">Back to store</button><button type="button" onClick={() => setIsAdminOpen(true)} className="rounded-xl bg-[#f68b1e] px-4 py-2.5 text-sm font-bold text-white shadow-lg shadow-orange-500/20 transition hover:bg-orange-600"><Package className="mr-2 inline h-4 w-4" />Open orders</button></div></div>
            <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4"><div className="rounded-2xl bg-[#171b1d] p-5 text-white shadow-xl"><div className="flex items-center justify-between text-xs text-gray-400">Confirmed revenue <TrendingUp className="h-4 w-4 text-emerald-400" /></div><div className="mt-3 text-2xl font-black">NGN {confirmedRevenue.toLocaleString()}</div><div className="mt-2 text-[11px] text-emerald-300">+12.8% from last week</div></div><div className="rounded-2xl border border-gray-200 bg-white p-5 shadow-sm dark:border-gray-800 dark:bg-[#18181b]"><div className="text-xs font-bold text-gray-500">All orders</div><div className="mt-3 text-2xl font-black">{customerOrders.length}</div><div className="mt-2 text-[11px] text-gray-500">{deliveredCustomerOrders.length} delivered</div></div><div className="rounded-2xl border border-gray-200 bg-white p-5 shadow-sm dark:border-gray-800 dark:bg-[#18181b]"><div className="text-xs font-bold text-gray-500">Needs attention</div><div className="mt-3 text-2xl font-black text-red-500">{pendingCustomerOrders.length}</div><div className="mt-2 text-[11px] text-red-500">Pending payment review</div></div><div className="rounded-2xl border border-gray-200 bg-white p-5 shadow-sm dark:border-gray-800 dark:bg-[#18181b]"><div className="text-xs font-bold text-gray-500">Live customers</div><div className="mt-3 text-2xl font-black">{new Set(customerOrders.map((order) => order.phone)).size}</div><div className="mt-2 text-[11px] text-gray-500">Unique shoppers</div></div></div>
            <div className="mt-5 grid gap-5 xl:grid-cols-[1.15fr_0.85fr]"><section className="rounded-2xl border border-gray-200 bg-white p-5 shadow-sm dark:border-gray-800 dark:bg-[#18181b]"><div className="flex items-center justify-between"><div><h2 className="font-black">Order health</h2><p className="mt-1 text-xs text-gray-500">Payment and fulfilment mix</p></div><button onClick={() => setIsSalesReportOpen(true)} className="text-xs font-bold text-[#f68b1e]">View report</button></div><div className="mt-6 flex items-center gap-8"><div className="relative grid h-36 w-36 shrink-0 place-items-center rounded-full" style={{ background: `conic-gradient(#f68b1e 0 ${pieConfirmed}%, #4f8cff ${pieConfirmed}% ${pieConfirmed + pieProcessing}%, #19a974 ${pieConfirmed + pieProcessing}% 100%)` }}><div className="grid h-24 w-24 place-items-center rounded-full bg-white text-center dark:bg-[#18181b]"><strong className="text-2xl">{customerOrders.length}</strong><span className="text-[10px] text-gray-500">total orders</span></div></div><div className="space-y-4 text-xs"><div><span className="mr-2 inline-block h-2.5 w-2.5 rounded-full bg-[#f68b1e]" />Confirmed <strong className="ml-4">{pieConfirmed}%</strong></div><div><span className="mr-2 inline-block h-2.5 w-2.5 rounded-full bg-[#4f8cff]" />Processing <strong className="ml-4">{pieProcessing}%</strong></div><div><span className="mr-2 inline-block h-2.5 w-2.5 rounded-full bg-[#19a974]" />Delivered <strong className="ml-4">{pieDelivered}%</strong></div></div></div></section><section className="rounded-2xl border border-gray-200 bg-white p-5 shadow-sm dark:border-gray-800 dark:bg-[#18181b]"><div className="flex items-center justify-between"><div><h2 className="font-black">Admin chat</h2><p className="mt-1 text-xs text-gray-500">Your operations copilot</p></div><MessageCircle className="h-5 w-5 text-[#f68b1e]" /></div><div className="mt-4 h-28 space-y-2 overflow-y-auto rounded-xl bg-gray-50 p-3 text-xs dark:bg-[#202024]">{adminChatMessages.map((message, index) => <div key={`${message.text}-${index}`} className={message.from === 'admin' ? 'ml-8 rounded-lg bg-[#f68b1e] p-2 text-white' : 'mr-8 rounded-lg bg-white p-2 text-gray-600 shadow-sm dark:bg-[#303035] dark:text-gray-200'}>{message.text}</div>)}</div><form className="mt-3 flex gap-2" onSubmit={(event) => { event.preventDefault(); const text = adminChatInput.trim(); if (!text) return; setAdminChatMessages((messages) => [...messages, { from: 'admin', text }, { from: 'support', text: 'I have noted that. Open Live Support for a team response.' }]); setAdminChatInput(''); }}><input value={adminChatInput} onChange={(event) => setAdminChatInput(event.target.value)} placeholder="Ask about an order..." className="min-w-0 flex-1 rounded-xl border border-gray-200 bg-white px-3 py-2 text-xs outline-none focus:border-[#f68b1e] dark:border-gray-700 dark:bg-[#202024]" /><button aria-label="Send chat message" className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-[#f68b1e] text-white"><Send className="h-4 w-4" /></button></form><button onClick={() => handleOpenHelpSection('live-chat')} className="mt-3 text-xs font-bold text-[#f68b1e]">Open live support</button></section></div>
            <section className="mt-5 rounded-2xl border border-gray-200 bg-white p-5 shadow-sm dark:border-gray-800 dark:bg-[#18181b]"><div className="mb-4 flex items-center justify-between"><div><h2 className="font-black">Priority queue</h2><p className="mt-1 text-xs text-gray-500">Orders that may need your attention</p></div><button onClick={() => setIsAdminOpen(true)} className="text-xs font-bold text-[#f68b1e]">Manage all</button></div>{pendingCustomerOrders.length === 0 ? <div className="rounded-xl bg-emerald-50 p-4 text-sm font-bold text-emerald-700">You are all caught up.</div> : <div className="divide-y divide-gray-100 dark:divide-gray-800">{pendingCustomerOrders.slice(0, 3).map((order) => <button key={order.id} onClick={() => setIsAdminOpen(true)} className="flex w-full items-center justify-between gap-4 py-3 text-left transition hover:bg-gray-50 dark:hover:bg-[#202024]"><div className="flex min-w-0 items-center gap-3"><div className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-red-50 text-red-500 dark:bg-red-950/30"><AlertTriangle className="h-4 w-4" /></div><div className="min-w-0"><div className="truncate text-sm font-bold">Order #{order.id}</div><div className="text-xs text-gray-500">{order.phone || 'Customer'} · {order.date}</div></div></div><span className="shrink-0 rounded-full bg-red-50 px-3 py-1 text-[10px] font-black text-red-600 dark:bg-red-950/30">Review payment</span></button>)}</div>}</section>
          </main>
        </div>

        <AdminOrderAlert
          order={adminOrderAlert}
          onOpenOrders={() => {
            setAdminOrderAlert(null);
            setIsAdminOpen(true);
          }}
          onDismiss={() => setAdminOrderAlert(null)}
        />

        <AdminOrdersModal
          isOpen={isAdminOpen}
          onClose={() => setIsAdminOpen(false)}
          onEnableNotifications={enableAdminNotifications}
          orders={orders.filter((order) => order.orderSource === 'customer')}
          onConfirmOrderPayment={handleConfirmOrderPayment}
          onOpenStockManagement={() => setIsStockOpen(true)}
          onOpenSalesReport={() => setIsSalesReportOpen(true)}
          onOpenCustomerManagement={() => setIsCustomerManagementOpen(true)}
          onOpenLiveGps={(orderId) => {
            setIsAdminOpen(false);
            handleOpenLiveTracking(orderId);
          }}
          onUpdateOrderStatus={(orderId, status) => {
            setOrders((prev) =>
              prev.map((order) =>
                order.id === orderId
                  ? { ...order, status }
                  : order
              )
            );
            void updateOrderStatus(orderId, status).catch(() => {
              showToast('Could not sync status. Check Firebase connection.');
            });
          }}
          onUpdateOrderDelivery={(orderId, delivery) => {
            setOrders((prev) => prev.map((order) => order.id === orderId ? { ...order, ...delivery } : order));
            void updateOrderDelivery(orderId, delivery).catch(() => {
              showToast('Could not sync delivery details. Check Firebase connection.');
            });
            showToast('Delivery assignment saved');
          }}
        />
        <ConfirmOrdersModal
          isOpen={isConfirmOrdersOpen}
          onClose={() => setIsConfirmOrdersOpen(false)}
          orders={orders.filter(
            (order) => order.orderSource === 'customer' && order.paymentConfirmed !== true
          )}
          onConfirmOrder={handleConfirmOrderPayment}
        />
        <AdminStockModal
          isOpen={isStockOpen}
          onClose={() => setIsStockOpen(false)}
          stockLevels={stockLevels}
          onUpdateStock={handleUpdateStock}
          products={products}
          onSaveProduct={(product) => {
            setProducts((previous) => {
              const updated = previous.some((item) => item.id === product.id)
                ? previous.map((item) => item.id === product.id ? product : item)
                : [product, ...previous];
              return updated;
            });
            showToast('Product saved');
          }}
          onDeleteProduct={(productId) => {
            setProducts((previous) => previous.filter((product) => product.id !== productId));
            showToast('Product deleted');
          }}
        />

        <AdminSalesReportModal
          isOpen={isSalesReportOpen}
          onClose={() => setIsSalesReportOpen(false)}
          orders={orders.filter((order) => order.orderSource === 'customer')}
        />

        <AdminCustomersModal
          isOpen={isCustomerManagementOpen}
          onClose={() => setIsCustomerManagementOpen(false)}
          orders={orders.filter((order) => order.orderSource === 'customer')}
          onToast={showToast}
          onUpdateCustomerState={(email, state: AccountState) => updateCustomerAccountState(email, state)}
        />

        <Toast message={toastMessage} />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#f5f5f5] dark:bg-[#0f0f0f] text-gray-900 dark:text-gray-100 transition-colors">
      <AdminOrderAlert
        order={adminOrderAlert}
        onOpenOrders={() => {
          setAdminOrderAlert(null);
          setIsAdminOpen(true);
        }}
        onDismiss={() => setAdminOrderAlert(null)}
      />
      {/* 1. Header */}
      <Header
        theme={theme}
        onToggleTheme={toggleTheme}
        cartCount={totalCartCount}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenLogin={() => setIsLoginOpen(true)}
        isLoggedIn={isLoggedIn}
        accountName={accountName}
        onOpenHelpSection={handleOpenHelpSection}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onSearchSubmit={handleSearchSubmit}
        products={allProducts}
        onSelectProduct={handleSelectProduct}
        onOpenTrackOrder={() => handleOpenLiveTracking()}
        onOpenOrderHistory={() => setIsOrderHistoryOpen(true)}
        onSelectCategory={handleSelectCategory}
        onOpenAdmin={openAdminPortal}
        onOpenConfirmOrders={() => setIsConfirmOrdersOpen(true)}
        isAdmin={isLoggedIn && currentUserEmail.toLowerCase() === ADMIN_EMAIL}
      />

      {/* 2. Top Category Pills Bar */}
      <CategoryNav
        selectedCategory={selectedCategory}
        onSelectCategory={handleSelectCategory}
      />

      {/* 3. Main Container Grid */}
      <main className="max-w-7xl mx-auto px-3 sm:px-4 py-4 flex-1 w-full">
        <div className="flex gap-4">
          {/* Left Category Sidebar */}
          <Sidebar
            selectedCategory={selectedCategory}
            onSelectCategory={handleSelectCategory}
          />

          {/* Right Main Content Area */}
          <div className="flex-1 min-w-0">
            {/* If Single Product Detail is active */}
            {selectedProduct ? (
              <ProductDetail
                product={selectedProduct}
                stock={getStockLevel(selectedProduct.id)}
                onBack={handleBackToCatalog}
                onAddToCart={handleAddToCart}
                reviews={reviews}
                onAddReview={handleAddReview}
                onVoteHelpful={handleVoteHelpful}
              />
            ) : isSearching ? (
              /* Search / Category Filter Results View */
              <div className="bg-white dark:bg-[#1a1a1a] rounded-xl p-4 sm:p-5 mb-6 shadow-xs border border-gray-200 dark:border-gray-800 animate-fadeIn">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 mb-4 border-b border-gray-200 dark:border-gray-800 gap-2">
                  <div>
                    <h2 className="text-base sm:text-lg font-bold text-gray-900 dark:text-gray-100">
                      Showing results for: <span className="text-[#f68b1e]">"{searchQuery}"</span>
                    </h2>
                    <p className="text-xs text-gray-500">
                      {filteredList.length} products found
                    </p>
                  </div>

                  {/* Sort by dropdown */}
                  <div className="flex items-center gap-2 text-xs">
                    <span className="text-gray-500 flex items-center gap-1 font-semibold">
                      <ArrowUpDown className="w-3.5 h-3.5" /> Sort by:
                    </span>
                    <select
                      value={sortOption}
                      onChange={(e) => setSortOption(e.target.value as any)}
                      className="px-2.5 py-1.5 rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-[#242424] text-gray-800 dark:text-gray-200 focus:outline-none focus:border-[#f68b1e]"
                    >
                      <option value="featured">Featured</option>
                      <option value="price-low">Price: Low to High</option>
                      <option value="price-high">Price: High to Low</option>
                      <option value="rating">Top Customer Rated</option>
                    </select>
                  </div>
                </div>

                {filteredList.length === 0 ? (
                  <div className="text-center py-16 text-gray-400 text-xs">
                    <SlidersHorizontal className="w-10 h-10 mx-auto mb-3 opacity-40" />
                    <p>No products match your search criteria. Try a different query.</p>
                    <button
                      onClick={() => handleSelectCategory('all')}
                      className="mt-3 text-xs font-bold text-[#f68b1e] hover:underline"
                    >
                      Browse All Categories
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                    {filteredList.map((product) => (
                      <ProductCard
                        key={product.id}
                        product={product}
                        onAddToCart={handleAddToCart}
                        onSelectProduct={handleSelectProduct}
                      />
                    ))}
                  </div>
                )}
              </div>
            ) : (
              /* Standard Home Marketplace Feed */
              <>
                {/* Hero Slider with side ads */}
                <HeroSlider onSelectCategory={handleSelectCategory} />

                {/* Customer Care Hotline Callout */}
                <CustomerBanner />

                {/* Shop by Category Quick Grid */}
                <div className="bg-white dark:bg-[#1a1a1a] rounded-xl p-4 mb-4 shadow-xs border border-gray-200 dark:border-gray-800">
                  <div className="flex items-center justify-between pb-2 mb-3 border-b border-[#f68b1e]">
                    <h2 className="text-base font-bold text-gray-900 dark:text-gray-100">
                      Shop by Category
                    </h2>
                  </div>
                  <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-2">
                    {categoryCards.map((cat) => (
                      <button
                        key={cat.id}
                        onClick={() => handleSelectCategory(cat.id)}
                        className="bg-gray-50 dark:bg-[#222222] border border-gray-200 dark:border-gray-800 rounded-xl p-3 flex flex-col items-center justify-center text-center gap-1.5 hover:border-[#f68b1e] hover:shadow-xs transition-all cursor-pointer group"
                      >
                        <div className="group-hover:scale-110 transition-transform">
                          {cat.icon}
                        </div>
                        <span className="text-xs font-bold text-gray-700 dark:text-gray-300 group-hover:text-[#f68b1e]">
                          {cat.label}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Flash Sales with Live Timer */}
                <FlashSales
                  products={flashProducts}
                  onAddToCart={handleAddToCart}
                  onSelectProduct={handleSelectProduct}
                  onSeeAll={() => handleSelectCategory('all')}
                />

                {/* Top Brands Strip */}
                <BrandsStrip onSearchBrand={handleSearchSubmit} />

                {/* Category Section: Phones & Tablets */}
                <div className="bg-white dark:bg-[#1a1a1a] rounded-xl p-4 mb-4 shadow-xs border border-gray-200 dark:border-gray-800">
                  <div className="flex items-center justify-between pb-2 mb-3 border-b-2 border-[#f68b1e]">
                    <h2 className="text-base font-extrabold text-gray-900 dark:text-gray-100">
                      📱 Phones &amp; Tablets
                    </h2>
                    <button
                      onClick={() => handleSelectCategory('phone')}
                      className="text-xs font-bold text-[#f68b1e] hover:underline cursor-pointer"
                    >
                      See All →
                    </button>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                    {allProducts
                      .filter((p) => p.category === 'phone')
                      .slice(0, 8)
                      .map((p) => (
                        <ProductCard
                          key={p.id}
                          product={p}
                          onAddToCart={handleAddToCart}
                          onSelectProduct={handleSelectProduct}
                        />
                      ))}
                  </div>
                </div>

                {/* Category Section: Laptops & Computers */}
                <div className="bg-white dark:bg-[#1a1a1a] rounded-xl p-4 mb-4 shadow-xs border border-gray-200 dark:border-gray-800">
                  <div className="flex items-center justify-between pb-2 mb-3 border-b-2 border-[#f68b1e]">
                    <h2 className="text-base font-extrabold text-gray-900 dark:text-gray-100">
                      💻 Laptops &amp; Computers
                    </h2>
                    <button
                      onClick={() => handleSelectCategory('laptop')}
                      className="text-xs font-bold text-[#f68b1e] hover:underline cursor-pointer"
                    >
                      See All →
                    </button>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                    {allProducts
                      .filter((p) => p.category === 'laptop')
                      .slice(0, 8)
                      .map((p) => (
                        <ProductCard
                          key={p.id}
                          product={p}
                          onAddToCart={handleAddToCart}
                          onSelectProduct={handleSelectProduct}
                        />
                      ))}
                  </div>
                </div>

                {/* Category Section: Fashion & Shoes */}
                <div className="bg-white dark:bg-[#1a1a1a] rounded-xl p-4 mb-4 shadow-xs border border-gray-200 dark:border-gray-800">
                  <div className="flex items-center justify-between pb-2 mb-3 border-b-2 border-[#f68b1e]">
                    <h2 className="text-base font-extrabold text-gray-900 dark:text-gray-100">
                      👟 Fashion &amp; Footwear
                    </h2>
                    <button
                      onClick={() => handleSelectCategory('fashion')}
                      className="text-xs font-bold text-[#f68b1e] hover:underline cursor-pointer"
                    >
                      See All →
                    </button>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                    {allProducts
                      .filter((p) => p.category === 'fashion')
                      .slice(0, 8)
                      .map((p) => (
                        <ProductCard
                          key={p.id}
                          product={p}
                          onAddToCart={handleAddToCart}
                          onSelectProduct={handleSelectProduct}
                        />
                      ))}
                  </div>
                </div>

                {/* Category Section: Home Appliances */}
                <div className="bg-white dark:bg-[#1a1a1a] rounded-xl p-4 mb-4 shadow-xs border border-gray-200 dark:border-gray-800">
                  <div className="flex items-center justify-between pb-2 mb-3 border-b-2 border-[#f68b1e]">
                    <h2 className="text-base font-extrabold text-gray-900 dark:text-gray-100">
                      🏠 Home &amp; Kitchen Appliances
                    </h2>
                    <button
                      onClick={() => handleSelectCategory('appliance')}
                      className="text-xs font-bold text-[#f68b1e] hover:underline cursor-pointer"
                    >
                      See All →
                    </button>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                    {allProducts
                      .filter((p) => p.category === 'appliance')
                      .slice(0, 8)
                      .map((p) => (
                        <ProductCard
                          key={p.id}
                          product={p}
                          onAddToCart={handleAddToCart}
                          onSelectProduct={handleSelectProduct}
                        />
                      ))}
                  </div>
                </div>

                {/* Category Section: Gaming Gear */}
                <div className="bg-white dark:bg-[#1a1a1a] rounded-xl p-4 mb-4 shadow-xs border border-gray-200 dark:border-gray-800">
                  <div className="flex items-center justify-between pb-2 mb-3 border-b-2 border-[#f68b1e]">
                    <h2 className="text-base font-extrabold text-gray-900 dark:text-gray-100">
                      🎮 Gaming Consoles &amp; Accessories
                    </h2>
                    <button
                      onClick={() => handleSelectCategory('gaming')}
                      className="text-xs font-bold text-[#f68b1e] hover:underline cursor-pointer"
                    >
                      See All →
                    </button>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                    {allProducts
                      .filter((p) => p.category === 'gaming')
                      .slice(0, 8)
                      .map((p) => (
                        <ProductCard
                          key={p.id}
                          product={p}
                          onAddToCart={handleAddToCart}
                          onSelectProduct={handleSelectProduct}
                        />
                      ))}
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </main>

      {/* 4. Footer */}
      <Footer
        onOpenHelpSection={(sec) => {
          if (sec === 'track-order') {
            handleOpenLiveTracking();
          } else {
            handleOpenHelpSection(sec);
          }
        }}
      />

      {/* 5. Cart Slide-over Drawer */}
      <CartSidebar
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cart={cart}
        onChangeQty={handleChangeQty}
        onRemoveItem={handleRemoveCartItem}
        onOpenCheckout={handleStartCheckout}
      />

      {/* 6. Checkout Modal */}
      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        cart={cart}
        onCompleteOrder={handleCompleteOrder}
        showToast={showToast}
      />

      {/* 7. Payment Success Modal */}
      <PaymentSuccessModal
        isOpen={isPaymentSuccessOpen}
        onClose={() => setIsPaymentSuccessOpen(false)}
        method={lastPaymentMethod}
        orderId={lastPlacedOrderId || undefined}
        isOrderConfirmed={Boolean(
          lastPlacedOrderId && orders.find((order) => order.id === lastPlacedOrderId)?.paymentConfirmed
        )}
        onOpenTrackLiveOrder={handleOpenLiveTracking}
      />

      {/* 8. Login / Account Modal */}
      <LoginModal
        isOpen={isLoginOpen}
        onClose={() => setIsLoginOpen(false)}
        isLoggedIn={isLoggedIn}
          isAccessBlocked={isCustomerAccessBlocked}
        onLoginSuccess={async (id, name) => {
          const state = await getCustomerAccountState(id);
          if (state.revokedAt || state.disabled || state.deletedAt) {
            setIsCustomerAccessBlocked(true);
            showToast('This account is blocked by NeoMart support.');
            return;
          }
          const startedAt = Date.now();
          setIsLoggedIn(true);
          setCurrentUserEmail(id);
          setAccountName(name || id.split('@')[0]);
          setSessionStartedAt(startedAt);
          localStorage.setItem('neomart_logged_in', 'true');
          localStorage.setItem('neomart_user_email', id);
          localStorage.setItem('neomart_account_name', name || id.split('@')[0]);
          localStorage.setItem('neomart_session_started_at', String(startedAt));
          if (id.toLowerCase() === ADMIN_EMAIL.toLowerCase()) {
            setCurrentView('admin');
            window.history.pushState({}, '', '/admin');
          }
          void saveCustomerProfile({
            email: id.includes('@') ? id : undefined,
            displayName: name || id.split('@')[0],
            phone: auth?.currentUser?.phoneNumber || undefined,
          }).catch(() => {});
        }}
        onLogout={() => {
          setIsLoggedIn(false);
          setCurrentUserEmail('');
          setAccountName('');
          setIsAdminOpen(false);
          localStorage.removeItem('neomart_logged_in');
          localStorage.removeItem('neomart_user_email');
          localStorage.removeItem('neomart_account_name');
          localStorage.removeItem('neomart_session_started_at');
        }}
        showToast={showToast}
      />

      {/* 9. Help Center Modal */}
      <HelpCenterModal
        isOpen={isHelpOpen}
        section={activeHelpSection}
        onClose={() => setIsHelpOpen(false)}
        onSelectSection={setActiveHelpSection}
        onStartShopping={() => {
          setIsSearching(false);
          setSelectedCategory('all');
          setSelectedProductId(null);
        }}
        showToast={showToast}
        onOpenLiveTracking={handleOpenLiveTracking}
      />

      {/* 10. Live Order Tracking Modal with GPS Animated Courier Map */}
      <OrderTrackingModal
        isOpen={isOrderTrackingOpen}
        onClose={() => setIsOrderTrackingOpen(false)}
        orderId={trackingOrderId}
        ordersList={orders}
        showToast={showToast}
      />

      <OrderHistoryModal
        isOpen={isOrderHistoryOpen}
        onClose={() => setIsOrderHistoryOpen(false)}
        orders={customerOrdersForAccount}
        onTrackOrder={(orderId) => {
          setIsOrderHistoryOpen(false);
          handleOpenLiveTracking(orderId);
        }}
      />

      {/* 11. Admin Orders and Payment Manager */}
      <AdminOrdersModal
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
        onEnableNotifications={enableAdminNotifications}
        orders={orders.filter((order) => order.orderSource === 'customer')}
        onConfirmOrderPayment={handleConfirmOrderPayment}
        onOpenStockManagement={() => setIsStockOpen(true)}
        onOpenSalesReport={() => setIsSalesReportOpen(true)}
        onOpenCustomerManagement={() => setIsCustomerManagementOpen(true)}
        onOpenLiveGps={(orderId) => {
          setIsAdminOpen(false);
          handleOpenLiveTracking(orderId);
        }}
        onUpdateOrderStatus={(orderId, status) => {
          setOrders((prev) =>
            prev.map((order) =>
              order.id === orderId
                ? { ...order, status }
                : order
            )
          );
          void updateOrderStatus(orderId, status).catch(() => {
            showToast('Could not sync status. Check Firebase connection.');
          });
        }}
        onUpdateOrderDelivery={(orderId, delivery) => {
          setOrders((prev) => prev.map((order) => order.id === orderId ? { ...order, ...delivery } : order));
          void updateOrderDelivery(orderId, delivery).catch(() => {
            showToast('Could not sync delivery details. Check Firebase connection.');
          });
          showToast('Delivery assignment saved');
        }}
      />
      <ConfirmOrdersModal
        isOpen={isConfirmOrdersOpen}
        onClose={() => setIsConfirmOrdersOpen(false)}
        orders={orders.filter(
          (order) => order.orderSource === 'customer' && order.paymentConfirmed !== true
        )}
        onConfirmOrder={handleConfirmOrderPayment}
      />
      <AdminStockModal
        isOpen={isStockOpen}
        onClose={() => setIsStockOpen(false)}
        stockLevels={stockLevels}
        onUpdateStock={handleUpdateStock}
        products={products}
        onSaveProduct={(product) => {
          setProducts((previous) => {
            const updated = previous.some((item) => item.id === product.id)
              ? previous.map((item) => item.id === product.id ? product : item)
              : [product, ...previous];
            return updated;
          });
          showToast('Product saved');
        }}
        onDeleteProduct={(productId) => {
          setProducts((previous) => previous.filter((product) => product.id !== productId));
          showToast('Product deleted');
        }}
      />

      <AdminSalesReportModal
        isOpen={isSalesReportOpen}
        onClose={() => setIsSalesReportOpen(false)}
        orders={orders.filter((order) => order.orderSource === 'customer')}
      />

      <AdminCustomersModal
        isOpen={isCustomerManagementOpen}
        onClose={() => setIsCustomerManagementOpen(false)}
        orders={orders.filter((order) => order.orderSource === 'customer')}
        onToast={showToast}
        onUpdateCustomerState={(email, state: AccountState) => updateCustomerAccountState(email, state)}
      />

      {/* 12. Global Toast Alert */}
      <Toast message={toastMessage} />

      {/* 13. Initial Loading / Splash Screen */}
      {showSplash && (
        <SplashScreen
          onFinish={() => setShowSplash(false)}
          minDurationMs={2200}
        />
      )}
    </div>
  );
}
